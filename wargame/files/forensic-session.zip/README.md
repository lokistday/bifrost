# S7 세션의 흔적

실제 SQLite 파일 events.sqlite에서 session=S7이며 action=read인 기록의 fragment를 seq 순서로 복원하세요. 원본 복사본을 읽기 전용으로 조사하세요.

목표: SQL 필터와 순서를 근거로 FLAG를 복원합니다.

이 ZIP 안의 교육용 표본만 사용합니다. 원본을 보관하고 작업 사본에서 진행하세요.
FLAG 형식: BIFROST{...}
실행 중인 외부 서비스나 타인의 자료는 대상이 아닙니다.
