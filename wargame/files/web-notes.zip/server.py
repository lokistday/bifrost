# Python 3.10+ · localhost only. Deliberately missing an ownership check.
from http.server import BaseHTTPRequestHandler, HTTPServer
import base64
class App(BaseHTTPRequestHandler):
    def do_GET(self):
        notes = {'/notes/1': b'alice: shopping list', '/notes/2': base64.b64decode('QklGUk9TVHtvYmplY3Rfc2NvcGVfaXNfc2VydmVyX3NpZGV9')}
        body = notes.get(self.path,b'not found')
        self.send_response(200 if self.path in notes else 404)
        self.send_header('Content-Type','text/plain; charset=utf-8');self.end_headers();self.wfile.write(body)
if __name__=='__main__':
    print('Training app: http://127.0.0.1:8899/notes/1 ; stop with Ctrl+C')
    HTTPServer(('127.0.0.1',8899),App).serve_forever()
