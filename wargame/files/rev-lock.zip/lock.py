import base64
target=[102, 100, 103, 106, 113, 97]
key=input('key: ')
if [b^0x23 for b in key.encode()[::-1]]==target:
    print(base64.b64decode('QklGUk9TVHtyZXZlcnNlX3RoZV90cmFuc2Zvcm19').decode())
else:
    print('locked')
