import json,base64
from fnmatch import fnmatchcase
policy=json.load(open('policy.json',encoding='utf-8'))
principal=input('principal: ')
matches=[r for r in policy['rules'] if fnmatchcase(principal,r['principal']) and r['action']=='read' and r['resource']=='training']
if any(r['effect']=='Deny' for r in matches): print('DENY')
elif any(r['effect']=='Allow' for r in matches): print(base64.b64decode(policy['object']['body']).decode())
else: print('DENY')
