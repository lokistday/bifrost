# 좁아지는 길이

Ubuntu/WSL의 GCC로 gate.c를 gcc -std=c11 -Wall -Wextra gate.c -o gate로 빌드합니다. ./gate에 정수 하나를 입력해 requested는 크지만 accepted는 0이 되게 하세요. 메모리 손상은 일으키지 않는 정수 변환 모형입니다.

목표: 32비트 입력을 16비트로 줄일 때의 값 변화를 계산해 FLAG를 출력합니다.

이 ZIP 안의 교육용 표본만 사용합니다. 원본을 보관하고 작업 사본에서 진행하세요.
FLAG 형식: BIFROST{...}
실행 중인 외부 서비스나 타인의 자료는 대상이 아닙니다.
