#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
int main(void) {
    uint32_t requested=0;
    if(scanf("%" SCNu32,&requested)!=1) return 1;
    uint16_t accepted=(uint16_t)requested;
    if(requested>65535 && accepted==0) {
        unsigned char data[]={24,19,28,8,21,9,14,33,52,59,40,40,53,45,5,57,59,41,46,5,45,51,62,63,5,51,52,42,47,46,39};
        for(size_t i=0;i<sizeof data;i++) putchar(data[i]^0x5a);
        putchar('\n');return 0;
    }
    puts("locked");return 1;
}
